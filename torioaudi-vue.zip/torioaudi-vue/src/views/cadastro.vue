<template>
    <div class="Cadastro">
        cadstro futuramente
    </div>
</template>